# Handoff: OPTIQON Voice — premium redesign, feedback loop, Conversation

Target codebase: `LarsAhls/optiqon-voice` (Kotlin, Jetpack Compose, Material 3). **The repository is the source of truth for architecture.** This document describes desired product behaviour, user-visible states, constraints and acceptance criteria. Where it mentions tables, services, workers or class names, that is non-binding context from the design side; inspect the codebase and decide HOW.

## Overview
A redesign of the Android dictation app for non-technical users: a three-step first run (language → connect Groq → permissions), a calmer Home built around the Optiqon mark, simplified Profiles and Settings (jargon moved under "Advanced"), a new floating-bubble recording pill, and an in-app "Give feedback" channel with a status loop back to the sender. Dark theme only.

## About the design files
`OPTIQON Voice.dc.html` is a **design reference built in HTML** — it shows intended look, copy and motion. It is not code to ship. Recreate the screens in the existing Compose codebase using the app's own theme (`ui/theme/Color.kt`, `Type.kt`, `Shape.kt`), `AppChrome.kt` components, and Material 3 widgets. Open the HTML in a browser; it is a pan/zoom canvas with five turns, newest at the top: **turn 1 (bottom)** is the current app rebuilt from source for comparison, **turn 2** the redesign, **turn 3** the feedback feature, **turn 4** the Conversation workflow (profiles carry a workflow type), **turn 5** the first-run overview and empty Home, **turn 6 (top)** the implementation-readiness corrections (feedback discovery, setup and failure states). Option ids (2a, 3b, 4f, 6d …) are referenced below. Screenshots of every screen are in `screens/`, named by id; 3d.png is retained for reference only.

## Fidelity
**High fidelity.** Colours, type sizes, spacing and copy are final. Match them 1:1 (values are dp/sp; the HTML uses px at 1×). Two font swaps are intentional design decisions and need bundling: Cormorant Garamond (display) and Public Sans (UI) — see Typography.

## Provider and model names are illustrative
Every provider or model name on a screen ("Groq", "whisper-large-v3", "Llama 3.3 70B") is example runtime text, not a product decision. The design is capability-driven: Dictation needs high-quality speech transcription; Conversation needs speaker-separated transcription; cleanup and write-ups need suitable text processing. Verify current supported and recommended providers before wiring anything, show the actually configured provider/model at runtime under Advanced, and do not hard-code the examples as requirements.

## Privacy and safety wording (binding)
- Dictation and conversation audio goes only to the speech service selected for that workflow, unless the user explicitly enables another documented behaviour.
- OPTIQON receives data only when the user deliberately submits Feedback. Feedback context never includes API keys or dictation/conversation contents.
- Never claim "no servers" or "always skipped". Approved user-facing lines: 2c footer "Your voice goes only to the speech service you chose. OPTIQON hears from you only if you send feedback."; 2c step 3 "Voice does not type into password fields or other protected fields."; 3b helper "These details travel with your message so it can be reproduced. Your API key and your dictations never do."
- Acceptance: verify that password fields and the supported high-risk contexts (e.g. `textPassword` variants, fields flagged sensitive by the framework) are blocked from automatic text injection, and document what is covered.

---

## Design tokens

### Colours (dark theme)
Existing palette from `Color.kt` is kept; three surface values are new.

| Role | Hex | Notes |
|---|---|---|
| background | `#0F1513` | **new** — replaces Ink100 `#111311` as `background` |
| surface / card | `#182220` | **new** — replaces Slate110 `#1E2725`; also bottom-sheet bg |
| surface raised (segment selected, buttons on cards) | `#1F2B28` | **new** |
| hairline / divider | `rgba(255,255,255,.06)` | list dividers, nav top border |
| card border (rest) | `rgba(255,255,255,.05–.08)` | 1.5dp |
| card border (selected / active) | `rgba(126,200,186,.45–.5)` + halo `0 0 0 6dp rgba(126,200,186,.05)` | |
| onBackground / text | `#F2F4F1` | |
| text secondary | `#98A6A0` | |
| text tertiary / disabled | `#5F6964` (Ink40) | |
| primary | `#7EC8BA` (Pine80) | buttons, active nav, links |
| onPrimary | `#0A2E28` (Pine110) | |
| primaryContainer | `#1A6B5A` (Pine100) | done-check circles, "Sent" state |
| onPrimaryContainer | `#E3F0ED` (Pine50) | |
| secondary chip ("Recommended") | bg `#E4CEAA` (Sand90) · text `#2B200B` (Sand110) | |
| tertiary / attention | `#F0B498` (Clay80) | record-stop button, error pill, feedback badge, unread dot |
| onTertiary | `#351A0F` (Clay110) | |
| error surface | `rgba(53,26,15,.96)` border `rgba(240,180,152,.45)` text `#FFEDE4` | bubble error pill |
| status Implemented | bg `rgba(126,200,186,.16)` text `#7EC8BA` | |
| status Looking into it | bg `rgba(228,206,170,.16)` text `#E4CEAA` | |
| status Parked / Not planned | bg `rgba(152,166,160,.16)` text `#98A6A0` | |
| logo tile | bg `#F2F0EB`, ring `#15120E`, dot+tail `#4C7358` | light tile variant |
| logo on dark | ring `#F2F4F1`, dot+tail `#7EC8BA` | |

Remove the `ElevatedCard` usage on Home: it pulls Material's default `surfaceContainerLow` (#1D1B20, purple-tinted). Use `Card` with `surface`.

### Typography
Two families, bundled as font resources (Google Fonts, OFL):
- **Cormorant Garamond 600** — display/headline/numerals. Sizes used: 88/88 (hero number, ls −0.02em), 48/52 and 40/44 (onboarding & page titles, ls −0.01em), 36/40 (Home headline), 32/36 (stat numbers), 26/30, 24/28 (sheet title), 22/26 (provider name), 17 & 15 (wordmark "Optiqon Voice" beside logo tile), 13 (small wordmark caps, ls .06em).
- **Public Sans** — everything else. 400 for body (16/24, 15/22, 14/20, 13/18, 12/16), 500 for row titles (16/22) and meta (13, 12), 600 for buttons/labels (16, 15, 14, 13, 12, 11), 700 for tiny badges (9–11).
- Nav labels 12/16, 500 (600 + primary colour when selected).
- Section eyebrows: 12/16, 600, ls .08em, uppercase, `#98A6A0`.

Map onto `Typography`: displayLarge 88, displaySmall 48, headlineLarge 40, headlineMedium 36, headlineSmall 32, titleLarge 24, titleMedium 16/500 sans, bodyLarge 16/24, bodyMedium 15/22 or 14/20, bodySmall 13/18, labelLarge 14/600, labelMedium 12/500, labelSmall 11/600.

### Radii
Cards 22–24dp · onboarding option rows 18dp · bottom sheet top 28dp · buttons pill (56dp tall → 28dp) · chips pill · inline chips 8dp · text fields 14–16dp · logo tile ≈ 0.33 × size · recording pill 32dp (64dp tall) · bubble idle 24dp (48dp).

### Spacing
Screen horizontal padding 24dp (onboarding 28dp) · status bar 44dp · header row 44dp · section gap 16–22dp · card padding 16–20dp (18dp vertical rows) · list-row padding 16dp 18dp · bottom nav 80dp with 1dp top hairline (no filled indicator) · FAB bottom = nav + 20dp.

### Shadows
Primary FAB: `0 10 30 rgba(126,200,186,.25)` · floating pills over other apps: `0 12 40 rgba(0,0,0,.5)` · bottom sheet: `0 −20 60 rgba(0,0,0,.5)` · heads-up notification: `0 16 40 rgba(0,0,0,.6)` · selected onboarding row: `0 8 24 rgba(0,0,0,.35)`.

### Logo (vector)
ViewBox 0 0 120 120: ring `circle cx60 cy60 r44 stroke-width 12`, dot `circle r12`, tail `line 76,89 → 90,103 stroke-width 12 round caps`. Tile variant: light rounded square, mark at 78 % of tile size. Feedback variant: same tile with a 26 %-size rotated square at bottom-left as a speech tail (`assets/optiqon-logo-*.png` are the supplied originals).

---

## Screens

### Order a new user meets them (5b)
2a → 2b → 2c → Home (5a, empty state). **Feedback is not part of onboarding.** Exits: "I'll use another provider" (2b) opens the advanced provider form then returns to 2c; "Finish later" (2c) goes Home with a banner "2 permissions missing" that reopens 2c. Result: a profile **Standard** (Svenska, cleanup on) exists, the bubble service is running, onboarding is marked complete and never shown again unless the app is reset.

### 5a Home · first launch (empty state)
Same layout as 2d/4d. Headline "You're all set"; body "The bubble is on. Open Messages or Gmail, tap a text field, tap the bubble, and talk. Your first dictation shows up here." Stats show 0 / 0 / 0s in `#5F6964`. In place of the Recent list: a dashed card (1dp dashed `rgba(255,255,255,.12)`, radius 20, padding 22 20, centred): 44dp surface circle with pine mic, "Nothing dictated yet" 15/500, "Try it in a chat. Say "Hej, testar Optiqon Voice" and watch it land." 13 secondary.

### 2a First run · Language (1 of 3)
Column, 28dp sides. Top row: wordmark (tile 24 + "Optiqon Voice" 17 Cormorant) left, "1 of 3" 12/500 `#98A6A0` right. 56dp gap; **Optiqon mark 120dp** centred with two pulsing rings (border 1.5dp pine at .55/.35 alpha, scale 1→1.7, fade out, 3s ease-out, second ring 1.5s offset) and a soft glow `0 20 60 rgba(126,200,186,.22)`. 48dp gap; headline "Speak.\nIt types." 48/52. Body 16/24 secondary: "A small bubble floats over your apps. Tap it, talk, and clean text lands where your cursor is." Label 13/500 "Which language do you speak most?" Options (60dp tall, radius 18, bg surface, 1.5dp border): **Svenska** preselected — pine border, shadow, "Rekommenderat" 11/500 pine, 24dp pine check circle right; **English**; **Let the app detect it** with sub-line "Slightly less accurate" 12 — unselected rows have 24dp outline circle `#5F6964`. Bottom: **Continue** 56dp pill primary. Selecting a row: 150ms border/colour tween + 2dp lift.

### 2b First run · Connect (2 of 3)
Header: back arrow 44dp hit area, wordmark centred (tile 22 + 15 text), "2 of 3". Headline 40/44 "Connect a\nspeech service". Body: "Your voice is sent to a service that turns it into text. Groq is free to start, fast, and works well with Swedish." **Groq card** (radius 24, pine border .45 + 6dp halo, padding 22 20): title "Groq" 22 Cormorant + chip "Recommended" (Sand); line 14/20 secondary "Free tier · about one second per sentence · Whisper large v3"; key field 56dp (bg background, radius 16, hairline) showing masked key `gsk_••••••••••••••7Qx2` ls .12em with **Paste** button (40dp, radius 12, bg `#1F2B28`, pine text + copy icon) inside right; verification line 14/500 pine with check-circle icon: "Connected · Swedish test phrase came back in 0.8 s" — appears automatically after paste (test call with a short Swedish sample); helper 13/18: "No key yet? **Get a free one at console.groq.com**. Click *Create API key*, give it a name, and paste it above." — link opens `https://console.groq.com/keys` in the browser, pine 600 underlined. Below card: centred text button "I'll use another provider" → advanced provider form (existing SettingsScreen provider fields). **Continue** enabled only after a successful verification.

### 2c First run · Permissions (3 of 3)
Same header. Headline "Three things\nAndroid asks for". Body: "Each one opens a system screen. Flip the switch there and come back — this list updates by itself." Checklist rows (16–18dp vertical padding, hairline dividers), each with a 32dp circle at left: **1 Use the microphone** — done state: pine-filled circle with check, title struck through in secondary, "Done" 13 pine at right. **2 Show over other apps** — active: pine-outlined numbered circle, title 16/600, body "Lets the bubble float on top of your chat or mail app.", button **Open Android settings →** (44dp pill, bg `#1F2B28`, pine border .3, pine text). **3 Type into other apps** — pending: grey outlined circle, title and body in `#98A6A0` / `#5F6964`: "Places the text at your cursor. Voice does not type into password fields or other protected fields." Footer 13 tertiary centred: "Your voice goes only to the speech service you chose. OPTIQON hears from you only if you send feedback." Secondary button **Finish later** (56dp pill, bg surface, hairline, text secondary). Re-check permissions when the app returns to the foreground and advance the active step automatically; when all three are granted → Home (5a).

### 6a Feedback discovery (replaces 3d as the introduction)
Shown once, on Home, after the first successful dictation (fallback: on the third app open if no dictation has happened). Card in the Recent area under the first dictation row: surface, 1dp pine .3 border, radius 20, padding 14; feedback tile 36 at left; title "Something off? Tell Lars." 15/600; body "The small icon up top is a direct line to the person who builds Voice. Free text, optional screenshot." 13 secondary; buttons **Show me** (36dp pine pill → opens the feedback sheet 3b) and **Not now** (text); × top-right. Any of the three dismisses it permanently. It never blocks dictation, never reappears, and the feedback icon (3a) is present regardless. The 3d screen and its 14 s demo are retired as an onboarding gate; the demo may optionally play inside the sheet the first time it opens.

### 2d Home
Header row: wordmark left; right side a **profile chip** (32dp pill, bg surface: 18dp "SV" circle in primaryContainer + "Svenska · Groq" 13/500) and, 10dp to its right, the **feedback icon** (3a). 24–40dp gap; **Optiqon mark 150dp** with the same breathing rings (120dp in the variant that shows the feedback icon; either is fine — use 150 when the header has no badge). Headline 36/40 centred "The bubble is on" (off state: "The bubble is off"). Body 15/22 secondary centred "Open any app, tap the bubble in a text field, and talk." Ghost button 44dp pill, hairline border, stop-circle icon + "Turn off for now" (off state: primary filled "Turn on"). Stats strip: 3 equal columns, hairline top/bottom, 16dp vertical padding, inner vertical hairlines; numbers 32/36 Cormorant, labels 12/500 secondary: "12 dictations today", "412 words", "3m 08s spoken" (unit glyphs at 20sp). Row "Recent" 13/600 secondary left, "All history" 13/500 pine right. List rows (14dp vertical padding, hairline): text 15/22 clamped to 2 lines, meta 12/500 secondary "13:02 · Signal · 16 words". Bottom nav: Home (mic icon) · Profiles (tune) · Settings (gear); icons 24dp, labels 12; selected = pine, no indicator pill; 1dp top hairline; bg background.

### 2e Profiles
Title row: "Profiles" 40/44 with logo tile 32 at right. Body 15/22 secondary: "A profile is a set of choices: language, how much to clean up, and tone. The bubble uses the one that is on." Cards (radius 24, padding 18 18 18 20, gap 12): leading 24dp radio (active: pine fill with 10dp dark dot; inactive: 1.5dp `#5F6964` outline); name 18/600 + for active a chip "In use" (status Implemented colours); one-line plain-language summary 14/20 secondary — Svenska: "Removes filler, fixes slips, keeps your tone"; English: "Transcribe only, no cleanup"; Work mail: "Polished and formal, tightened a little"; chevron 20dp `#5F6964` right. Active card gets pine border + halo and a second row of 8dp-radius chips (bg background, 12/500 secondary): "Whisper large v3 · Groq" · "Cleanup on" · "3 word fixes". Tap radio = activate; tap row = editor (existing ProfileEditScreen restyled with these tokens). Footer 13 tertiary centred: "Switch profiles from the bubble too: press and hold it." Extended FAB bottom-right: 56dp pill primary "New profile" with plus icon, pine glow.

Summary text is derived: rewrite FIX → "fixes slips", POLISH → "Polished and formal", llm off → "Transcribe only, no cleanup", summarize LIGHT → "tightened a little", HARD → "condensed hard", OutputStyle MINIMAL → "lowercase".

### 2f Settings
Title row "Settings" + tile 32. Groups with eyebrow (CONNECTION · BUBBLE · HISTORY), each a radius-22 surface card with 16/18dp rows and hairline dividers. **Connection**: "Speech service" → sub "● Groq · connected" (8dp pine dot); "Text cleanup" → "● Groq · Llama 3.3 70B". Both navigate to a provider screen (URL, key, model, Save/Test — existing `ProviderSettingsSection`, restyled). **Bubble**: "Come back after restart" switch; "Stop when I go quiet" → sub "After 2 seconds" (slider 0.5–5 s on tap); "Vibrate on start and stop" switch. **History**: "Keep my dictations" sub "On this phone only · last 500" switch; "Word fixes" sub "5 words the app always corrects" → replacement-rules screen. Last card **Advanced & about Optiqon Voice** sub "Own servers, model names, prompts, version" → existing prompts / built-ins / clipboard fallback / pause-other-audio / keep-stats / retention / version / GPL notice / "Delete my feedback". Switch: 48×28, track pine when on with 22dp `#0A2E28` thumb; off: track `#2A322F`, 1.5dp `#5F6964` border, 14dp `#98A6A0` thumb.

### 2g Floating bubble (overlay, `BubbleView` / `FanMenuView`)
- **Idle**: 48dp circle, bg `rgba(15,21,19,.94)`, 1dp border `rgba(126,200,186,.35)`, shadow; Optiqon mark 28dp (light ring, pine dot) centred. Replaces the grey dot.
- **Recording pill**: 300×64dp, radius 32, same bg/border, `backdrop blur 12`; left 44dp **stop** circle Clay `#F0B498` with 16dp dark square; centre live **waveform** — 11 bars 3dp wide, gap 3, height 10–26dp driven by `updateAudioLevel`, pine; timer 15/600 tabular; right 44dp **pause** circle `rgba(255,255,255,.06)` with two 4×16 bars. Tap anywhere except pause/stop = stop. Long-press = profile switcher.
- **Profile switcher**: row of 40dp pills 6dp apart above the pill; active = pine filled, dark text 13/600; others bg `rgba(15,21,19,.94)` border pine .25, text 13/500.
- **Processing**: 48dp pill "Cleaning up…" 14/500 with 18dp pine arc spinner (1 s linear).
- **Error**: pill bg `rgba(53,26,15,.96)`, border Clay .45, text "Couldn't reach Groq" `#FFEDE4`, inner **Retry** button 36dp Clay filled.
- Motion: idle→pill expands from the dot's centre 220 ms ease-out; pill→"Cleaning up…" collapse 180 ms; brief pine check 600 ms before returning to idle.

### 4b Profiles (replaces 2e when Conversation is enabled)
Same card component as 2e. Two groups with eyebrows: **TYPES INTO ANY APP** (Standard "Dictation · Svenska" active with model chips; Clean "Polished dictation · Svenska") and **RECORDS A CONVERSATION · SAVED IN VOICE** (Customer meeting "Summary, decisions and actions"; Interview "Detailed transcript and summary"). Sub-line carries a 14dp glyph: mic (pine) for dictation, two-people outline (sand `#E4CEAA`) for conversation. Body copy: "A profile decides what Voice does when you tap it. The one that is on applies everywhere." Until Conversation is enabled the second group does not render and the list is identical to 2e.

### 4c Profile editor
Header: back · profile name 24 Cormorant · check (save). Name card. Eyebrow **WHAT THIS PROFILE DOES**: two side-by-side option cards (radius 18, 1.5dp border, selected = pine border + shadow + pine check circle): "Types as I speak — Short dictation, straight into the app I'm in." (mic) and "Records a conversation — Longer session. Speakers separated. Saved here in Voice." (people). This sets `workflowType` (DICTATION | CONVERSATION); never derive it from the name. Eyebrow **LANGUAGE SPOKEN**: chips Auto / Svenska / English. For CONVERSATION: eyebrow **AFTER THE RECORDING, WRITE** with rows Transcript ("Every speaker on their own line", label "Always"), Summary ("Short · a few sentences", switch), Decisions ("What was agreed", switch), Action items ("Who does what, by when", switch). For DICTATION: the turn-2 cleanup rows (post-processing toggle, Style) instead. Last: "Advanced — Transcription service for conversations, cleanup model" →. Type card is shown only when Conversation is enabled; otherwise DICTATION is implied.

### 4d / 4e Home by active profile type
4d (DICTATION active) = 2d with the profile chip reading "Standard · Svenska" (18dp pine circle with mic). 4e (CONVERSATION active): chip "Customer meeting" (sand circle, people glyph) with the wordmark reduced to the tile; headline "Ready to record a conversation"; body "Voice records everyone in the room, then writes it up speaker by speaker with a summary, decisions and actions. It stays here in Voice; nothing is typed into other apps."; primary 56dp pill **Start conversation** (people icon) replaces the ghost button; stats strip removed; "Recent conversations" list rows: 40dp surface square with people glyph, title 15/500, meta 12 "43 min · 3 speakers · Customer meeting", right "Yesterday".

### 6b / 6c Conversation "Needs setup" state (only when Conversations are enabled)
Condition: a CONVERSATION profile exists but no speaker-separating transcription service is configured or verified. Then: in Profiles (6c) conversation profiles carry a sand chip **Needs setup** and the group eyebrow gets one line "These need a speech service that can separate speakers. Tap one to set it up."; on Home with such a profile active (6b) the headline is "Conversations need a quick setup", body "This profile records a whole conversation and tells the speakers apart. That needs a speech service that can separate voices; the one you dictate with cannot. About a minute.", the primary action is **Set up conversations →** (surface pill, 1.5dp sand .5 border) instead of Start conversation, and a card lists what setup means (1 pick a service that can separate speakers · 2 paste its key, Voice checks it with a short test · 3 come back and start recording) plus "Dictation keeps working as usual with your other profiles." The bubble confirm pill (4a) opens the same setup screen. Setup itself is the Advanced › Conversations provider form (4o) with a verification call. **Acceptance:** a user can never reach a Start action that fails for lack of capability.

### 4a Overlay with conversation profiles
Profile switcher (long-press) pills gain a 16dp leading glyph: mic for dictation, people for conversation; active pill unchanged (pine fill). With a CONVERSATION profile active the idle bubble gets an 18dp sand badge (people glyph) bottom-right; a tap does **not** record — it shows a 56dp pill "Start conversation / Customer meeting · opens in Voice" (40dp sand circle with people glyph); confirming opens 4f in the app. While a conversation records and the user is elsewhere, the bubble becomes a 44dp chip: bg `rgba(15,21,19,.96)`, 1dp border `rgba(240,180,152,.45)`, pulsing clay dot (10dp + expanding ring 1.6s), timer 14/600 tabular, "Conversation · tap to return" 12 secondary. Tap returns to 4f.

### 4f Conversation recording (in-app, full screen)
Header: chevron-down (minimise, keeps recording) · chip "Customer meeting" · spacer. 56dp gap; eyebrow row centred: pulsing clay dot + "RECORDING" 12/600 ls .08em `#F0B498`. Timer 96/96 Cormorant tabular `#F2F4F1`. "Started 10:04 · Svenska" 14 secondary. Waveform 23 bars (same spec as 2g) in a 56dp band. Note 14 `#5F6964`: "Keeps recording if you switch apps or lock the phone. You'll see the time in your notifications and on the bubble." Bottom controls, 44dp apart: **Pause** 80dp surface circle with two 6×24 bars, label 13; **Stop & write up** 64dp clay circle with 24dp dark square. Foreground service + persistent notification with elapsed time; screen may sleep.

### 4g Conversation paused
Same surface. Eyebrow: two sand bars + "PAUSED" sand. Timer in `#98A6A0`. Waveform replaced by a 240×2 line `#3A433F`. Note: "Nothing is being recorded. Resume when you are ready, or stop to have it written up." Controls: **Resume** 80dp pine circle with play icon (label in `#F2F4F1`), Stop unchanged.

### 4h Conversation processing
Header as 4f with back. Optiqon mark 120dp with breathing rings. "Writing it up" 40/44. Body: "43 minutes of audio. Separating the speakers, then the summary. Usually done in a minute or two." Progress bar 240×4 (track surface, fill pine). Status line with 18dp pine spinner: "Transcript ready · writing the summary". Footer "You can leave. Voice tells you when it's ready." + secondary button **Back to Home**. Notification when done → 4i.

### 6d Write-up failed (transcription or diarization)
Same surface as 4h. Headline "Couldn't write it up"; body "The speech service didn't answer. Your 43-minute recording is safe on this phone and stays until a transcript exists."; status chip (clay-tinted) "No response from the speech service · 10:52"; primary **Try again**; line "Voice also retries by itself when you are back online."; footer "Kept in History as "Not written up yet" until this works."; buttons **Back to Home** (secondary) and **Delete recording** (clay text, confirm dialog). Principles: a completed recording is never lost silently; audio is not deleted until a durable transcript exists (regardless of the "Keep the audio" setting); the user can leave at any time; History shows the item with state "Not written up yet" and the same Try again / Delete actions; automatic retry with backoff when connectivity returns.

### 6e Transcript ready, optional write-ups failed
Transcript screen (4i) with a sand-bordered banner above the segments: "**Transcript is ready.** The summary, decisions and actions couldn't be written. The transcript is saved either way." with **Write them now** (pine pill) and **Keep transcript only** (text). The "Summary & actions" tab carries a 7dp sand dot while pending. Principles: a failure in Summary/Decisions/Actions never invalidates or hides the transcript; partial success is stated plainly; retry is per write-up, not a re-transcription; audio may be deleted once the transcript exists even if write-ups are pending.

### 4i–4k Conversation transcript
Header: back · copy · overflow (40dp surface circles). Eyebrow chip glyph + "CUSTOMER MEETING" 12/600 sand ls .06em. Title 32/36 Cormorant (editable, default = profile name + date). Meta 13 "Yesterday 10:04 · 43 min · 3 speakers". Segmented tabs (as 3b): **Transcript** | **Summary & actions** (second tab only if the profile generated anything). **Hint card** (until all speakers named): surface, 1dp sand .3 border, 28dp sand-tinted circle with people glyph, "Voice heard 3 speakers but doesn't know who they are. Tap a label to name them." Segments: 14dp gap rows, hairline dividers; left column 64dp with a speaker chip (24dp pill, surface bg, 8dp colour dot, 11/600) and timestamp 11/500 `#5F6964` tabular; text 15/22. Speaker colours fixed by index: 1 pine `#7EC8BA`, 2 sand `#E4CEAA`, 3 clay `#F0B498` (4+ cycle with reduced alpha). After naming (4k) the hint is replaced by a participants row: "In this conversation" 12 secondary + chips per speaker; still-unnamed speakers get a 1dp dashed sand border and secondary text.

### 4j Rename speaker (bottom sheet)
Tap any speaker chip. Sheet (as 3b chrome): 14dp colour dot + "Who is Speaker 2?" 24 Cormorant; sub "Speaks 14 times in this conversation. The name applies to all of them."; 56dp text field (focused pine border); "Names you've used before" 12 secondary + plain text chips (36dp, hairline) from previous conversations on this device (`speaker_names` table: name, last_used); note 12 `#5F6964`: "Voice doesn't recognise voices. Names are set by you, one conversation at a time."; buttons **Name speaker** (primary 52dp) + Cancel. Renaming updates `speaker_label` on every segment with that `speaker_index` in this conversation only. No voiceprints, embeddings, suggestions or confidence.

### 4l Summary & actions tab
Sections with eyebrows, only those the profile enabled: **SUMMARY** body 16/25; **DECISIONS** bullet rows (5dp pine dot, 15/22, hairline); **ACTION ITEMS** rows with 22dp checkbox (radius 7; done = pine fill + check, text struck in secondary), text 15/22, meta 12 "Lars · this week" (owner = speaker label, due if stated). Footer 12 `#5F6964`: "Written by Voice from the transcript. Check anything you act on. Long-press a line to edit."

### 4m History
Header back + "History" 32 Cormorant. Filter row (36dp chips, active pine) All · Dictations (mic) · Conversations (people) — render the row only when at least one conversation exists. Day sections with eyebrow 13/600 secondary and optional right meta "142 words". Dictation rows as 2d Recent (text 2-line clamp, meta with 12dp mic glyph). Conversation cards: surface radius 20, padding 16 18, 40dp sand-tinted square with people glyph, title 16/600, time right 12 tertiary, meta 13 "43 min · Lars, Anna, Speaker 3", chips (8dp radius, bg background) e.g. Customer meeting · Summary · 2 decisions · 3 actions. Tap → 4i.

### 4n Settings (supersedes 2f)
Groups in order: **ACCOUNT** — one row "Using Voice on this phone / No account needed. Profiles, history and conversations stay here." with a 36dp person icon circle at right, no button, no chevron (a future signed-in state replaces text and avatar; no auth in this build). **CONNECTION** as 2f. **CONVERSATIONS** — "Keep the audio / Off · deleted once the transcript is written" switch (default off); "Remind me while recording / Every 30 minutes" → (haptic + notification pulse). **BUBBLE** as 2f. Last card "Advanced & about Optiqon Voice" → 4o. Conversations group hidden until the feature is enabled.

### 4o Advanced (screen)
Header back + "Advanced" 32. **SERVICES**: Dictation "Groq · whisper-large-v3 · api.groq.com" →; Text cleanup "Groq · llama-3.3-70b-versatile" →; Conversations — sand dot + "Not set up · needs speaker separation" → (provider form requiring a diarization-capable endpoint). **PROCESSING**: Prompts →; Word fixes →; "Fallback when cleanup fails / Insert the raw transcript" switch. **DATA**: History "Keep the last 500 dictations" →; "Delete my feedback" with clay "Delete" action; last row "Optiqon Voice / v20260904 · GPL-3.0" with 28dp logo tile.

### 2h / 2i (alternates, not for implementation unless chosen)
2h editorial Home (hero number 88sp); 2i single-screen onboarding. Kept for reference.

### 3a Feedback entry point
36dp circle button, bg surface, 1dp border pine .3, mark 20dp, small 7dp rotated-square speech tail bottom-left (same border). Placed in the header of Home, Profiles and Settings, far right (Home: right of the profile chip). Never on the overlay. Tap: button expands to a 52dp pill with label "Give feedback" (200 ms) while the bottom sheet slides up. Badge (3e): 16dp Clay circle with 2dp background border at top-right when there are unread status changes.

### 3b Feedback sheet · New message
Modal bottom sheet, scrim `rgba(6,9,8,.62)`, sheet bg surface, radius 28 top, padding 10 24 28, 36×4 handle. Header: feedback tile 40 + title "Give feedback" 24 Cormorant + sub 13/18 secondary "Goes straight to Lars, who builds the app. Every message is read." Segmented control (bg background, radius 14, 4dp padding; selected segment bg `#1F2B28`): **New message** | **Your feedback** (6dp Clay dot when unread). Text area min 132dp, radius 16, bg background, 1dp pine .35 border when focused, 15/22. Attachment row: 64dp thumbnail (radius 12) with 20dp remove button; **Add image** 44dp ghost pill (plus icon) → Android Photo Picker, one image, EXIF stripped, max ~1600px. Context chips 11/500 secondary radius 8: screen name · app version · "Android 15 · Pixel 8" · active profile "Svenska · Groq" (provider **host**, never key). Helper 12/17 tertiary: "These details travel with your message so it can be reproduced. Your API key and your dictations never do." **Send** 52dp primary pill. Offline: queue in Room `feedback_outbox`, show "Will send when online" in place of Send, flush on next open with network (`NetworkMonitor`).

### 3c Feedback sheet · Your feedback
Own items only, newest first, cards radius 18 bg background padding 14 16: status chip; quoted message 14/20 secondary; optional owner note in a nested `#182220` box 14/20 with "Lars:" 600; meta 12 tertiary "Sent 2 Sept · with screenshot". Unread item: pine border + 8dp Clay dot top-right. Implemented item shows buttons **Update & try it** (primary 40dp; opens the GitHub release / Obtainium when `installed < implemented_in`, else deep-links to the feature and label reads **Try it**) and **Got it** (text). Footer "Only you can see this list." Opening the tab marks items read → clears badge.

### 3e Update notification
Local heads-up notification (channel "Feedback", default importance): small icon = mark, title "Your feedback was implemented", text = status note, tap → app → sheet on "Your feedback". Fired by the poll (see State) — never more than one per status change.

---

## Interactions & motion
- Pulse rings (`ovRing`): scale 1→1.7, opacity .7→0, 3 s ease-out, infinite, staggered.
- Waveform bars: each bar `scaleY .35↔1`, 0.7–1.0 s alternate, 70 ms stagger; scale amplitude by audio level.
- Onboarding option select: 150 ms colour/border, 2dp translateY.
- Bottom sheet: standard M3 sheet, 300 ms decelerate; scrim fades in parallel.
- Feedback icon → pill expansion: 200 ms ease-out width animation; label fades in after 80 ms.
- **3d demo timeline (14 s loop, all ease-in-out)** — % of cycle: 0–2 % callout "Feedback lives up here, top right" fades in under the header icon (pine speech box 12/600) and holds to 12 %, out by 16 %; header icon rings visible until 11 %, hidden by 15 %; pointer (32dp translucent circle) appears at 3 % near the demo, travels to the header icon by 9 %, taps (scale .7) 11 %, back 13 %, fades by 17 %; header icon squeezes to .86 at 11 %; demo sheet slides up 14→18 %, holds to 57 %, slides down 57→61 %; text line 1 fades in 21–23 %, line 2 27–29 %; image thumb pops 35–38 %; "Send" becomes "Sent ✓" (primaryContainer) 48–50 %; "A FEW DAYS LATER" label 61–72 %; badge on the mini header icon pops 64–67 % and hides at 100 %; status card "Implemented — The bubble now remembers its spot in every app — Try it" slides up 71–74 %, holds to 95 %, out by 100 %. Implement with Compose `rememberInfiniteTransition` + `keyframes` on one shared 14 000 ms clock, or as a Lottie if preferred.

## Feature flag: design ready vs. feature enabled
A build-time or remote flag for Conversations, default off (mechanism up to the implementation). When false: no CONVERSATION group in Profiles, no type cards in the editor (new profiles are DICTATION), no Conversations group in Settings, no Conversations service row in Advanced, no History filter row, bubble behaves exactly as 2g. No "coming soon" UI anywhere. Data model may ship ahead of the flag so enabling it needs no redesign.

## Technical context (non-binding)
The notes below record how the design side imagined state and data. Treat them as hints; the repository's existing patterns win.
- **Onboarding**: `onboardingComplete: Boolean` in `PreferencesDataStore`; step state derived: language chosen → provider verified (`asrBaseUrl`, key, test OK) → permissions granted (existing `Permission*State`) → feedback intro seen. First run creates the "Svenska" profile with `language="sv"`, `asrModel="whisper-large-v3"`, LLM on if the Groq LLM test passes.
- **Recommended-provider preset**: whichever provider is currently recommended for high-quality Swedish transcription with a free tier (Groq at design time); one key may serve both transcription and cleanup if the provider offers both. Verification = one short transcription request with a bundled Swedish sample clip. Model IDs come from configuration, not code.
- **Home**: `serviceRunning` (`BubbleService.runningState`), today stats (`HomeViewModel.todayStats`), recent 2 (`HistoryRepository.recent()` limit 2), active profile + provider host for the chip.
- **Feedback**: `installationId` (UUID, generated once, stored in `SecurePreferencesStore`); Room tables `feedback_outbox` (pending sends) and `feedback_items` (server mirror: id, message, image_url, status, status_note, implemented_in, updated_at, read_at); `unreadCount = items.count { read_at == null && status != NEW }` drives the badge. Client talks only to an edge function (`POST /feedback`, `GET /feedback?installation=…`); statuses change server-side only. Poll on app open and once per 24 h from `BubbleService` (WorkManager acceptable); diff `updated_at` → insert rows → post local notification via `NotificationHelper`. Statuses: `new`, `looking`, `implemented` (+ version), `parked`, `not_planned`.
- **Profiles**: add `workflowType: DICTATION | CONVERSATION` (Room migration, default DICTATION) plus for CONVERSATION: `generateSummary`, `generateDecisions`, `generateActions` booleans. Behaviour keys off `workflowType`, never the name.
- **Conversations**: Room tables `conversations` (id, profileId, title, startedAt, durationMs, state: RECORDING|PAUSED|PROCESSING|READY|FAILED, audioPath nullable, summary, decisionsJson, actionsJson) and `conversation_segments` (conversationId, speakerIndex, speakerLabel, startMs, endMs, text); `speaker_names` (name, lastUsed) for the rename chips. Recording runs in the existing foreground service with its own notification channel "Conversation"; pause/resume/stop actions on the notification. Processing = upload → speaker-separated transcript → per-profile text passes for summary/decisions/actions → notify. States also include TRANSCRIPTION_FAILED (audio kept, retryable) and READY_PARTIAL (transcript saved, write-ups pending/failed). Audio deleted only after a durable transcript exists, and then only if "Keep the audio" is off.
- **Deletion**: Settings › Advanced → "Delete my feedback" calls `DELETE /feedback?installation=…` and clears local tables.

## Acceptance criteria
1. A new user reaches a working dictation through exactly three screens (2a, 2b, 2c) and Home; no feedback, account, conversation or model terminology on the way.
2. Dictation with a DICTATION profile behaves as in 2g: tap → speak → stop → cleaned text at the cursor. No new prompts or choices were added.
3. The feedback icon is present on Home, Profiles and Settings; the discovery card (6a) appears once, is dismissible three ways and never returns; the feedback sheet works without any account; feedback context contains no API key and no dictation text.
4. All user-facing privacy and safety copy matches the approved lines above; protected-field blocking is verified and documented.
5. With Conversations disabled: no conversation UI anywhere, no "coming soon".
6. With Conversations enabled but no capable service configured: "Needs setup" and "Set up conversations" appear; Start conversation is unreachable.
7. Conversation recording survives app switch and screen lock, shows elapsed time in a notification and on the bubble chip, supports pause/resume/stop.
8. A completed recording is never deleted before a durable transcript exists; failed transcription shows 6d with retry and delete; failed write-ups show 6e with the transcript intact.
9. Speaker labels default to Speaker 1…n with fixed colours; renaming applies to all segments of that speaker in that conversation only; nothing implies voice recognition.
10. Provider/model names shown under Advanced reflect runtime configuration; no example ID from this document is hard-coded as a requirement.
11. Visual output matches `screens/` at 412dp width within normal rendering tolerance; fonts are bundled.

## Assets
- `assets/optiqon-logo-tile.png`, `assets/optiqon-logo-mark.png` — supplied logo originals (white background); use the vector spec above for in-app rendering and the tile PNG as the launcher icon source.
- Icons: Material Icons (core) — arrow_back, arrow_forward, check, check_circle, close, add, content_copy, settings, tune, mic, stop_circle, chevron_right. Waveform, logo and pointer are drawn shapes.
- Fonts: Cormorant Garamond (500/600/700), Public Sans (400–700) — download from Google Fonts, add as `res/font`.

## Files
- `OPTIQON Voice.dc.html` — the design canvas (turns 1–5). Requires network for Google Fonts.
- `screens/*.png` — one screenshot per screen, named by option id (e.g. `4f.png`). Use these as the visual target.
- `PROMPT.md` — a suggested opening message for the Claude Code session.
- `assets/optiqon-logo-*.png`, `assets/screenshot01.png`, `assets/screenshot02.png` (old README screenshots, reference only).
- `github.md` — source-repo association and screen → file map.
