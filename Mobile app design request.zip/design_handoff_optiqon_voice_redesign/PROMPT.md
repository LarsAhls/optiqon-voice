# Prompt för Claude Code

Lägg handoff-mappen i repot (t.ex. `docs/handoff/`), starta Claude Code i repots rot och klistra in texten under strecket.

---

Läs docs/handoff/README.md i sin helhet innan du gör något. Det är en produkt- och designspec för OPTIQON Voice: önskat beteende, användarsynliga tillstånd, begränsningar och acceptanskriterier. Skärmdumpar per skärm finns i docs/handoff/screens/ (namngivna efter id). HTML-filen är en visuell referens, inte kod att porta.

Kodbasen är källan till sanning för arkitekturen. Tekniska anteckningar i README är icke-bindande; inspektera repot och bestäm själv hur beteendet bäst realiseras med befintliga mönster, komponenter, ViewModels och repositories.

Uppgift: implementera design och funktion enligt README så att alla acceptanskriterier (README › Acceptance criteria) uppfylls. Rimlig ordning är tema → first run → Home/Profiles/Settings/Advanced/bubbla → Feedback → Conversation bakom flagga, men planera själv och håll varje PR granskningsbar. Fråga mig bara när något är en riktig produktfråga eller kräver externa uppgifter, till exempel feedback-tjänstens URL och payload.

Bindande:
- Följ mått, färger och copy i README; dp/sp = px i specen. Där spec och skärmdump skiljer sig gäller specen.
- Provider- och modellnamn i specen är exempel. Verifiera vilka leverantörer som stöds och rekommenderas idag, håll dem konfigurerbara och visa faktisk konfiguration under Advanced.
- Integritets- och säkerhetstexterna i README › Privacy and safety wording används ordagrant. Verifiera och dokumentera att lösenordsfält och andra skyddade fält blockeras från automatisk textinmatning.
- Beteende styrs av profilens workflowType, aldrig av namnet. Inga voiceprints, talarigenkänning eller confidence.
- Ingen inloggning, ingen "coming soon"-UI. Feedback kräver inget konto och skickar aldrig API-nyckel eller dikteringar.
- En avslutad konversationsinspelning får aldrig raderas innan ett hållbart transkript finns; misslyckade sammanfattningar får inte dölja ett lyckat transkript.
- Skriv migrationer för alla schemaändringar.

Beslut som redan är tagna: ljud raderas efter transkript (Keep the audio = off), konversation från bubblan kräver bekräftelse-pillen, onamngiven talare får streckad chip utan upprepade påminnelser, feedback-kortet visas en gång efter första lyckade diktering.

Avsluta varje PR med byggstatus, emulator-skärmdumpar av berörda skärmar jämförda mot docs/handoff/screens/, och vilka acceptanskriterier som nu är uppfyllda.
