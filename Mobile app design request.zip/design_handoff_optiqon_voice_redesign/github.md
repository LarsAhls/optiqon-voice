repo: LarsAhls/optiqon-voice
branch: main
path: app/src/main

## Last sync
date: 2026-09-05T13:24:44Z

### Updated in this project
- Recreated current dark-theme UI (Home, Profiles, Edit profile, Style, Settings, bubble + fan menu) in `OPTIQON Voice.dc.html` turn 1
- Redesign directions (onboarding, permissions, Home, Profiles, Settings, bubble) in turn 2

## Screen map
| Screen | Repo files |
| --- | --- |
| 1a Home | ui/home/HomeScreen.kt, ui/common/AppChrome.kt, ui/navigation/AppNavGraph.kt, ui/theme/*.kt |
| 1b Profiles list | ui/profiles/ProfilesScreen.kt, ui/common/AppChrome.kt |
| 1c Edit profile | ui/profiles/ProfilesScreen.kt |
| 1d Style picker | ui/profiles/ProfilesScreen.kt |
| 1e Settings | ui/settings/SettingsScreen.kt, ui/settings/SettingsComponents.kt |
| 1f Bubble + fan menu | service/BubbleView.kt, service/FanMenuView.kt |
| Permissions (2c) | ui/common/PermissionHelper.kt |
| Icons | ui/theme/ExtendedIcons.kt, res/drawable/ic_launcher_foreground.xml |
